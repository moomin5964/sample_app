# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'b85b54cc78608e3a63306a500e182a465f15c15b798477835f06c6eaaac77cf6150ceef5da58e0320be8508afcf35e408d6da12872e9b7eecea8bd609447bd41'